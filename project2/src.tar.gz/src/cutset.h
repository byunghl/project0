// cutset.h

// Author : Byung Ho Lee

#ifndef CUTSET_H
#define CUTSET_H

// Structure for cutset information
struct cutset {
    double* aCutsets;

};

#endif