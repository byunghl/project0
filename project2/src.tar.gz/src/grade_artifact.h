// grade_artifact.h

// Author : Byung Ho Lee

#ifndef GRADE_ARTIFACT_H
#define GRADE_ARTIFACT_H

// Structure for graded artifact
struct grade_artifact {
    int possibleScore;
    int weight;
};

#endif